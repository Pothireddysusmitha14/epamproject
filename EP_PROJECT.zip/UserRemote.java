package com.model;

import java.util.List;

import javax.ejb.Remote;

import com.entity.User;

@Remote
public interface UserRemote 
{
public  String saveData(User U)throws Exception;
public List<User> getData() throws Exception;
public  String updateData(User U) throws Exception;
public String deleteData(User U) throws Exception;
}

