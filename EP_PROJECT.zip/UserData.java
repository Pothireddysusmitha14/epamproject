package com.controller;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;

import com.entity.User;
import com.model.UserRemote;


@ManagedBean(name="use",eager=true)
public class UserData {
	String firstname;
	String lastname;
	String email;
	String username;
	String password;
	String dob;
	String phonenumber;
	String response;
	List<User> list;
	@EJB(lookup="java:global/EP_PROJECT/UserManager!com.model.UserRemote")
	UserRemote ur;
	public void save()
	{
		try
		{
			User u=new User();
			u.setFirstname(firstname);
			u.setLastname(lastname);
			u.setEmail(email);
			u.setDob(dob);
			u.setPhonenumber(phonenumber);
			u.setUsername(username);
			u.setPassword(password);
			response =ur.saveData(u);
		}
		catch(Exception e)
		{
			response=e.getMessage();
		}
	}
	public void update()
	{
		try
		{
			User u=new User();
			u.setFirstname(firstname);
			u.setLastname(lastname);
			u.setEmail(email);
			u.setDob(dob);
			u.setPhonenumber(phonenumber);
			u.setUsername(username);
			u.setPassword(password);
			response=ur.updateData(u);
		}
		catch(Exception e)
		{
			response=e.getMessage();
		}
	}
	public void delete()
	{
		try
		{
			User u=new User();
			u.setFirstname(firstname);
			u.setLastname(lastname);
			u.setEmail(email);
			u.setDob(dob);
			u.setPhonenumber(phonenumber);
			u.setUsername(username);
			u.setPassword(password);
			response=ur.deleteData(u);
		}
		catch(Exception e)
		{
			response=e.getMessage();
		}
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}
	public List<User> getList()
	{
		try
		{
			list=ur.getData();
			
		}
		catch(Exception e)
		{
			response=e.getMessage();
		}
		return list;
	}
	public void setList(List<User> list) {
		this.list = list;
	}
}
