package com.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import com.entity.User;
@Stateless
public class UserManager implements UserRemote{
	@Override
	public String saveData(User U) throws Exception 
	{
		
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/klu","root","Harshitha@123");
		PreparedStatement ps=con.prepareStatement("insert into user values(?,?,?,?,?,?,?)");
		ps.setString(1, U.getFirstname());
		ps.setString(2, U.getLastname());
		ps.setString(3, U.getEmail());
		ps.setString(4, U.getDob());
		ps.setString(5, U.getPhonenumber());
		ps.setString(6, U.getUsername());
		ps.setString(7, U.getPassword());
		ps.execute();
		con.close();
		
		return "Record saved successfully";
	}

	@Override
	public List<User> getData() throws Exception
	{
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/klu","root","Harshitha@123");
		PreparedStatement ps=con.prepareStatement("select * from user ");
		ResultSet rs=ps.executeQuery();
		List<User> L=new ArrayList<User>();
		while(rs.next())
		{
			User u=new User();
			u.setFirstname(rs.getString(1));
			u.setLastname(rs.getString(2));
			u.setEmail(rs.getString(3));
			u.setDob(rs.getString(4));
			u.setPhonenumber(rs.getString(5));
			u.setUsername(rs.getString(6));
			u.setPassword(rs.getString(7));
			L.add(u);
		}
		con.close();
		return L;	
		
			
	}

	@Override
	public String updateData(User U) throws Exception 
	{
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/klu","root","Harshitha@123");
		PreparedStatement ps=con.prepareStatement("update user set email=?,phonenumber=? where username=?");
		ps.setString(1, U.getEmail());
		ps.setString(2, U.getPhonenumber());
		ps.setString(3,U.getUsername());
		ps.execute();
		con.close();
		return "Record updated Sucessfully";
	}
	

	@Override
	public String deleteData(User U) throws Exception 
	{
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/klu","root","Harshitha@123");
		PreparedStatement ps=con.prepareStatement("delete from user where username=?");
		ps.setString(1, U.getUsername());
		ps.execute();
		con.close();
		return "Record deleted successfully";
		
		
	}
}
	   